
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, MapPin, Clock, Mail, MessageCircle } from "lucide-react";

export const Contact = () => {
  const handleCall = () => {
    window.location.href = "tel:+256751936627";
  };

  const handleWhatsApp = () => {
    window.open("https://wa.me/256751936627?text=Hello%20Nemisas,%20I%20need%20sound%20equipment%20for%20my%20event", "_blank");
  };

  const contactInfo = [
    {
      icon: Phone,
      title: "Call Us",
      details: "0751 936 627",
      action: handleCall,
      description: "Available 24/7 for urgent bookings"
    },
    {
      icon: MessageCircle,
      title: "WhatsApp",
      details: "0751 936 627",
      action: handleWhatsApp,
      description: "Quick quotes and inquiries"
    },
    {
      icon: MapPin,
      title: "Visit Us",
      details: "Near Albayan Memorisation Center",
      description: "Iganga, Eastern Uganda"
    },
    {
      icon: Clock,
      title: "Business Hours",
      details: "Mon - Sun: 8:00 AM - 10:00 PM",
      description: "Emergency services available 24/7"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Power Your Event?
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Get in touch for a free consultation and quote. Our team is ready to help make your event unforgettable.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {contactInfo.map((info, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 text-center">
              <CardContent className="p-6">
                <div className="bg-gradient-to-br from-orange-500 to-blue-600 w-16 h-16 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <info.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{info.title}</h3>
                <p className="text-lg font-medium text-orange-600 mb-1">{info.details}</p>
                <p className="text-sm text-gray-600 mb-4">{info.description}</p>
                {info.action && (
                  <Button 
                    onClick={info.action}
                    variant="outline"
                    size="sm"
                    className="border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white"
                  >
                    Contact
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main CTA Section */}
        <div className="bg-gradient-to-r from-orange-500 to-blue-600 rounded-2xl p-8 md:p-12 text-white text-center">
          <h3 className="text-2xl md:text-3xl font-bold mb-4">
            Let's Make Your Event Extraordinary
          </h3>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            From sound consultation to full event production, we're here to ensure your event sounds perfect. 
            Call now for immediate assistance or to schedule a site visit.
          </p>
          
          <div className="flex flex-col md:flex-row gap-4 justify-center">
            <Button 
              onClick={handleCall}
              size="lg"
              className="bg-white text-orange-600 hover:bg-orange-50 px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
            >
              <Phone className="w-5 h-5 mr-2" />
              Call 0751 936 627
            </Button>
            <Button 
              onClick={handleWhatsApp}
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-orange-600 px-8 py-4 text-lg font-semibold rounded-full backdrop-blur-sm"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              WhatsApp Quote
            </Button>
          </div>
        </div>

        {/* Service Areas */}
        <div className="mt-16 text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">
            Serving Eastern Uganda
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {[
              "Iganga", "Jinja", "Mayuge", "Kamuli", "Kaliro", "Luuka", 
              "Namutumba", "Buyende", "Kibuku", "Pallisa", "Budaka", "Tororo"
            ].map((location, index) => (
              <span 
                key={index}
                className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium"
              >
                {location}
              </span>
            ))}
          </div>
          <p className="text-sm text-gray-600 mt-4">
            Specializing in: Parties, Graduations, Weddings, Rallies & Cultural Events
          </p>
        </div>
      </div>
    </section>
  );
};
