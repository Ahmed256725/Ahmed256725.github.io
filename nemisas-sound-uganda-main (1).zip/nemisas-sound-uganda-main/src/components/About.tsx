
import { Card, CardContent } from "@/components/ui/card";
import { Users, Award, Clock, MapPin } from "lucide-react";

export const About = () => {
  const stats = [
    {
      icon: Users,
      number: "500+",
      label: "Events Completed",
      description: "Successful events across Eastern Uganda"
    },
    {
      icon: Clock,
      number: "6+",
      label: "Years Experience",
      description: "Serving the community since 2018"
    },
    {
      icon: Award,
      number: "100%",
      label: "Client Satisfaction",
      description: "Committed to excellence in every event"
    },
    {
      icon: MapPin,
      number: "15+",
      label: "Districts Served",
      description: "Coverage across Eastern Uganda region"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Your Trusted Sound Partner in Eastern Uganda
            </h2>
            <div className="space-y-6 text-gray-600">
              <p className="text-lg">
                Nemisas Sound Systems has been the premier choice for event sound solutions in Iganga and across Eastern Uganda since 2018. We understand the unique needs of our community, from traditional ceremonies to modern celebrations.
              </p>
              <p>
                Located near Albayan Memorisation Center in Iganga, we've built our reputation on reliability, quality equipment, and exceptional service. Whether you're planning a wedding, graduation, political rally, or cultural event, our experienced team ensures your message is heard loud and clear.
              </p>
              <p>
                Our commitment goes beyond just providing equipment – we offer complete event production services, ensuring every technical detail is handled professionally so you can focus on what matters most: your event.
              </p>
            </div>

            <div className="mt-8 bg-orange-50 rounded-lg p-6">
              <h3 className="font-semibold text-gray-900 mb-3">Why Choose Nemisas?</h3>
              <ul className="space-y-2 text-gray-600">
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2"></span>
                  Local expertise with deep understanding of Ugandan events
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2"></span>
                  Professional-grade equipment maintained to highest standards
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2"></span>
                  Experienced crew trained in event production
                </li>
                <li className="flex items-start">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mr-3 mt-2"></span>
                  Competitive pricing with transparent, no-hidden-costs policy
                </li>
              </ul>
            </div>
          </div>

          {/* Right Stats */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                <CardContent className="p-6">
                  <div className="bg-gradient-to-br from-orange-500 to-blue-600 w-16 h-16 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="font-semibold text-gray-900 mb-2">{stat.label}</div>
                  <div className="text-sm text-gray-600">{stat.description}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
