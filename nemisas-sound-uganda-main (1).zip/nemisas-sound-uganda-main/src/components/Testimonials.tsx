
import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

export const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Namukasa",
      role: "Bride",
      event: "Wedding Reception",
      location: "Iganga",
      quote: "Nemisas made our wedding reception absolutely unforgettable! The sound was crystal clear and the lighting created such a romantic atmosphere. Our guests are still talking about how perfect everything was.",
      rating: 5,
      image: "👰🏾"
    },
    {
      name: "Hon. James Walugembe",
      role: "MP Candidate",
      event: "Political Rally",
      location: "Mayuge District",
      quote: "Our message reached over 5,000 people clearly thanks to Nemisas professional setup. Their team understood the importance of our campaign and delivered beyond expectations. Highly recommended!",
      rating: 5,
      image: "🗣️"
    },
    {
      name: "Dr. Margaret Nabunya",
      role: "School Administrator",
      event: "Graduation Ceremony",
      location: "Busoga University",
      quote: "Flawless sound for our graduation ceremony! Every speech was heard perfectly by all 2,000 attendees. The technical team was professional and handled everything seamlessly.",
      rating: 5,
      image: "🎓"
    },
    {
      name: "Emmanuel Waiswa",
      role: "Event Organizer",
      event: "Cultural Festival",
      location: "Jinja",
      quote: "Working with Nemisas for our annual cultural festival was a game-changer. They perfectly balanced traditional music with modern sound technology. The crowd was amazed!",
      rating: 5,
      image: "🎪"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Trusted by Uganda's Event Leaders
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            From intimate celebrations to massive gatherings, our clients trust us to deliver exceptional sound experiences that make their events memorable.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden">
              <CardContent className="p-6 relative">
                <Quote className="absolute top-4 right-4 w-8 h-8 text-orange-200" />
                
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xl mr-4">
                    {testimonial.image}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>

                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="ml-2 text-sm text-gray-600">
                    {testimonial.event} • {testimonial.location}
                  </span>
                </div>

                <blockquote className="text-gray-700 italic leading-relaxed">
                  "{testimonial.quote}"
                </blockquote>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">500+</div>
              <div className="text-gray-600">Happy Clients</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">0</div>
              <div className="text-gray-600">Failed Events</div>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-3xl font-bold text-green-600 mb-2">24/7</div>
              <div className="text-gray-600">Support Available</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
