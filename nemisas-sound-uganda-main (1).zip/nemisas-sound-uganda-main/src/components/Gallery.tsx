
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Play, X, Camera, Video } from "lucide-react";

export const Gallery = () => {
  const [selectedMedia, setSelectedMedia] = useState<any>(null);

  const mediaItems = [
    {
      id: 1,
      type: "image",
      title: "Wedding Reception - Iganga",
      category: "Weddings",
      description: "Complete sound setup for 300 guests",
      thumbnail: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=400&fit=crop",
      url: "https://images.unsplash.com/photo-1519741497674-611481863552?w=1200&h=800&fit=crop"
    },
    {
      id: 2,
      type: "video",
      title: "Political Rally - Mayuge District",
      category: "Rallies",
      description: "5,000+ crowd with crystal clear sound",
      thumbnail: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=600&h=400&fit=crop",
      url: "https://player.vimeo.com/video/example"
    },
    {
      id: 3,
      type: "image",
      title: "Graduation Ceremony - Busoga University",
      category: "Graduations",
      description: "Professional speech amplification for 2,000 attendees",
      thumbnail: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=400&fit=crop",
      url: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1200&h=800&fit=crop"
    },
    {
      id: 4,
      type: "image",
      title: "Cultural Festival - Jinja",
      category: "Cultural Events",
      description: "Traditional meets modern sound technology",
      thumbnail: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=600&h=400&fit=crop",
      url: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=1200&h=800&fit=crop"
    },
    {
      id: 5,
      type: "video",
      title: "Wedding Dance Floor Setup",
      category: "Weddings",
      description: "DJ booth and lighting for evening reception",
      thumbnail: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=600&h=400&fit=crop",
      url: "https://player.vimeo.com/video/example2"
    },
    {
      id: 6,
      type: "image",
      title: "Evening Party - Iganga Club",
      category: "Parties",
      description: "High-energy sound and laser lighting",
      thumbnail: "https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?w=600&h=400&fit=crop",
      url: "https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?w=1200&h=800&fit=crop"
    },
    {
      id: 7,
      type: "image",
      title: "Campaign Rally Stage Setup",
      category: "Rallies",
      description: "Heavy-duty speakers and stage monitoring",
      thumbnail: "https://images.unsplash.com/photo-1541872705-1f73c6400ec9?w=600&h=400&fit=crop",
      url: "https://images.unsplash.com/photo-1541872705-1f73c6400ec9?w=1200&h=800&fit=crop"
    },
    {
      id: 8,
      type: "image",
      title: "Outdoor Wedding Ceremony",
      category: "Weddings",
      description: "Romantic lighting and clear ceremony audio",
      thumbnail: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600&h=400&fit=crop",
      url: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&h=800&fit=crop"
    }
  ];

  const categories = ["All", "Weddings", "Rallies", "Graduations", "Parties", "Cultural Events"];
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredMedia = activeCategory === "All" 
    ? mediaItems 
    : mediaItems.filter(item => item.category === activeCategory);

  const openModal = (item: any) => {
    setSelectedMedia(item);
  };

  const closeModal = () => {
    setSelectedMedia(null);
  };

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Work in Action
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            See how we've powered unforgettable events across Eastern Uganda with professional sound, lighting, and technical excellence
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              onClick={() => setActiveCategory(category)}
              className={`rounded-full px-6 py-2 transition-all duration-300 ${
                activeCategory === category 
                  ? "bg-gradient-to-r from-orange-500 to-blue-600 text-white" 
                  : "border-gray-300 hover:border-orange-500"
              }`}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Media Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredMedia.map((item) => (
            <Card 
              key={item.id} 
              className="group cursor-pointer overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              onClick={() => openModal(item)}
            >
              <CardContent className="p-0">
                <div className="relative">
                  <img 
                    src={item.thumbnail} 
                    alt={item.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    {item.type === "video" ? (
                      <Play className="w-12 h-12 text-white" />
                    ) : (
                      <Camera className="w-12 h-12 text-white" />
                    )}
                  </div>
                  <Badge className="absolute top-3 right-3 bg-orange-500 text-white">
                    {item.type === "video" ? <Video className="w-3 h-3 mr-1" /> : <Camera className="w-3 h-3 mr-1" />}
                    {item.type === "video" ? "Video" : "Photo"}
                  </Badge>
                  <Badge className="absolute top-3 left-3 bg-blue-600 text-white">
                    {item.category}
                  </Badge>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-1">{item.title}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2">{item.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Modal */}
        {selectedMedia && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={closeModal}>
            <div className="relative max-w-4xl w-full max-h-[90vh] bg-white rounded-lg overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 z-10 bg-black/50 text-white hover:bg-black/70"
                onClick={closeModal}
              >
                <X className="w-6 h-6" />
              </Button>
              
              {selectedMedia.type === "video" ? (
                <div className="relative pt-[56.25%]">
                  <iframe
                    src={selectedMedia.url}
                    className="absolute inset-0 w-full h-full"
                    frameBorder="0"
                    allow="autoplay; fullscreen; picture-in-picture"
                    allowFullScreen
                    title={selectedMedia.title}
                  />
                </div>
              ) : (
                <img
                  src={selectedMedia.url}
                  alt={selectedMedia.title}
                  className="w-full h-auto max-h-[70vh] object-contain"
                />
              )}
              
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <Badge className="bg-blue-600 text-white">{selectedMedia.category}</Badge>
                  <Badge variant="outline">{selectedMedia.type === "video" ? "Video" : "Photo"}</Badge>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{selectedMedia.title}</h3>
                <p className="text-gray-600">{selectedMedia.description}</p>
              </div>
            </div>
          </div>
        )}

        {/* Stats */}
        <div className="mt-16 text-center bg-gradient-to-r from-orange-500 to-blue-600 rounded-2xl p-8 text-white">
          <h3 className="text-2xl md:text-3xl font-bold mb-6">
            Creating Memories Since 2018
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <div className="text-3xl font-bold mb-2">500+</div>
              <div className="text-orange-100">Events Powered</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">50+</div>
              <div className="text-orange-100">Wedding Receptions</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">25+</div>
              <div className="text-orange-100">Political Rallies</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">100+</div>
              <div className="text-orange-100">Graduation Ceremonies</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
