
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

export const FloatingContact = () => {
  const handleCall = () => {
    window.location.href = "tel:+256751936627";
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Button 
        onClick={handleCall}
        size="lg"
        className="bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white font-semibold py-4 px-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 animate-pulse"
      >
        <Phone className="w-5 h-5 mr-2" />
        <span className="hidden sm:inline">Call Now</span>
        <span className="sm:hidden">Call</span>
      </Button>
    </div>
  );
};
