
import { Button } from "@/components/ui/button";
import { Phone, MapPin, Star } from "lucide-react";

export const Hero = () => {
  const handleCall = () => {
    window.location.href = "tel:+256751936627";
  };

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-orange-600 via-orange-500 to-blue-600 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="absolute inset-0 opacity-30" style={{
        backgroundImage: "url('data:image/svg+xml;utf8,<svg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"><g fill=\"none\" fillRule=\"evenodd\"><g fill=\"%23ffffff\" fillOpacity=\"0.1\"><circle cx=\"30\" cy=\"30\" r=\"4\"/></g></g></svg>')"
      }}></div>
      
      <div className="relative container mx-auto px-4 py-20 flex flex-col items-center text-center text-white">
        {/* Logo/Brand */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-bold mb-2 bg-gradient-to-r from-white to-orange-200 bg-clip-text text-transparent">
            NEMISAS
          </h1>
          <p className="text-xl md:text-2xl font-semibold text-orange-200">
            SOUND SYSTEMS
          </p>
        </div>

        {/* Main Tagline */}
        <div className="max-w-4xl mb-8 animate-fade-in" style={{ animationDelay: "0.2s" }}>
          <h2 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
            Sound. Lights. Energy.<br />
            <span className="text-orange-300">Your Event, Amplified.</span>
          </h2>
          <p className="text-lg md:text-xl text-orange-100 mb-2">
            Rentals • Sales • Repairs • Full Event Production
          </p>
          <p className="text-base md:text-lg text-orange-200 flex items-center justify-center gap-2">
            <MapPin className="w-5 h-5" />
            Serving Iganga & Eastern Uganda Since 2018
          </p>
        </div>

        {/* Location & Rating */}
        <div className="flex flex-col md:flex-row items-center gap-4 mb-8 animate-fade-in" style={{ animationDelay: "0.4s" }}>
          <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full backdrop-blur-sm">
            <MapPin className="w-4 h-4" />
            <span className="text-sm md:text-base">Near Albayan Memorisation Center, Iganga</span>
          </div>
          <div className="flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full backdrop-blur-sm">
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="w-4 h-4 fill-yellow-300 text-yellow-300" />
              ))}
            </div>
            <span className="text-sm md:text-base">500+ Events Powered</span>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col md:flex-row gap-4 animate-fade-in" style={{ animationDelay: "0.6s" }}>
          <Button 
            onClick={handleCall}
            size="lg"
            className="bg-white text-orange-600 hover:bg-orange-50 px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            <Phone className="w-5 h-5 mr-2" />
            Call 0751 936 627
          </Button>
          <Button 
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white hover:text-orange-600 px-8 py-4 text-lg font-semibold rounded-full backdrop-blur-sm"
            onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
          >
            View Services
          </Button>
        </div>

        {/* Quick Services Preview */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-4xl animate-fade-in" style={{ animationDelay: "0.8s" }}>
          {[
            { icon: "🎓", text: "Graduations" },
            { icon: "💍", text: "Weddings" },
            { icon: "🗣️", text: "Rallies" },
            { icon: "🎉", text: "Parties" }
          ].map((service, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-lg p-4 text-center hover:bg-white/20 transition-all duration-300">
              <div className="text-2xl mb-2">{service.icon}</div>
              <p className="text-sm font-medium">{service.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
