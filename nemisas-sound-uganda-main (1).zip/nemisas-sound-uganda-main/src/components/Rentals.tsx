
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Phone } from "lucide-react";

export const Rentals = () => {
  const packages = [
    {
      name: "Wedding Package",
      price: "500,000",
      duration: "per day",
      popular: false,
      description: "Perfect for intimate weddings and receptions",
      equipment: [
        "2 Top Speakers (400W each)",
        "1 Bass Speaker (800W)",
        "Wireless Microphone System",
        "Basic Lighting Setup",
        "DJ Mixer & Setup"
      ],
      includes: ["Setup & breakdown", "2-hour testing", "Basic operator training"]
    },
    {
      name: "Rally Package",
      price: "1,200,000",
      duration: "per day",
      popular: true,
      description: "High-power setup for political rallies and large crowds",
      equipment: [
        "4 Top Speakers (800W each)",
        "2 Bass Speakers (1000W each)",
        "Generator & Power Distribution",
        "Stage Monitoring System",
        "Multiple Wireless Mics"
      ],
      includes: ["Professional crew", "Backup equipment", "Full technical support"]
    },
    {
      name: "Graduation Package",
      price: "350,000",
      duration: "per day",
      popular: false,
      description: "Clear speech and presentation setup for ceremonies",
      equipment: [
        "2 Top Speakers (300W each)",
        "Podium Microphone System",
        "Projection Screen Setup",
        "Basic Sound Mixing",
        "Ceremony Lighting"
      ],
      includes: ["Setup assistance", "Sound check", "Equipment backup"]
    }
  ];

  const handleCall = () => {
    window.location.href = "tel:+256751936627";
  };

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Equipment Rental Packages
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Professional sound systems grouped by event type with transparent pricing. All packages include delivery within Iganga town.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {packages.map((pkg, index) => (
            <Card key={index} className={`relative overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 ${pkg.popular ? 'ring-2 ring-orange-500' : ''}`}>
              {pkg.popular && (
                <Badge className="absolute top-4 right-4 bg-orange-500 hover:bg-orange-600 text-white">
                  Most Popular
                </Badge>
              )}
              <CardContent className="p-6">
                <div className="mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{pkg.description}</p>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold text-orange-600">UGX {pkg.price}</span>
                    <span className="text-gray-500 ml-2">/ {pkg.duration}</span>
                  </div>
                </div>

                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Equipment Included:</h4>
                  <ul className="space-y-2">
                    {pkg.equipment.map((item, idx) => (
                      <li key={idx} className="text-sm text-gray-600 flex items-start">
                        <Check className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Service Includes:</h4>
                  <ul className="space-y-2">
                    {pkg.includes.map((service, idx) => (
                      <li key={idx} className="text-sm text-gray-600 flex items-start">
                        <Check className="w-4 h-4 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                        {service}
                      </li>
                    ))}
                  </ul>
                </div>

                <Button 
                  onClick={handleCall}
                  className={`w-full font-semibold py-3 rounded-lg transition-all duration-300 ${
                    pkg.popular 
                      ? 'bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white' 
                      : 'bg-gray-900 hover:bg-gray-800 text-white'
                  }`}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info */}
        <div className="bg-blue-50 rounded-xl p-6 text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">
            Rental Terms & Conditions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
            <div>
              <strong className="text-gray-900">Deposit Required:</strong><br />
              50% advance payment to confirm booking
            </div>
            <div>
              <strong className="text-gray-900">Delivery Zone:</strong><br />
              Free delivery within Iganga town center
            </div>
            <div>
              <strong className="text-gray-900">Damage Policy:</strong><br />
              Client responsible for equipment damage
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
