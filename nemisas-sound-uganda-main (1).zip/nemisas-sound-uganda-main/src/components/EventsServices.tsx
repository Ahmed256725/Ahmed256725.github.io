
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { GraduationCap, Heart, Users, Megaphone, PartyPopper, Settings } from "lucide-react";

export const EventsServices = () => {
  const eventTypes = [
    {
      icon: GraduationCap,
      title: "Graduations",
      description: "PA systems, microphones, projectors for your special day",
      color: "from-blue-500 to-blue-600",
      features: ["Clear speech systems", "Projection screens", "Photography lighting"]
    },
    {
      icon: Heart,
      title: "Weddings",
      description: "Dance floor setups, wireless mics, mood lighting",
      color: "from-pink-500 to-red-500",
      features: ["Reception sound", "Ceremony mics", "Romantic lighting"]
    },
    {
      icon: Users,
      title: "Cultural Ceremonies",
      description: "Traditional sound blending with modern equipment",
      color: "from-green-500 to-emerald-600",
      features: ["Outdoor systems", "Cultural music", "Traditional setups"]
    },
    {
      icon: Megaphone,
      title: "Rallies & Campaigns",
      description: "Heavy-duty speakers, stage setups, generators",
      color: "from-orange-500 to-red-600",
      features: ["High-power speakers", "Crowd coverage", "Backup power"]
    },
    {
      icon: PartyPopper,
      title: "Parties & Clubs",
      description: "DJ booths, subwoofers, laser lights for the perfect vibe",
      color: "from-purple-500 to-pink-600",
      features: ["DJ equipment", "Dance lighting", "Bass systems"]
    },
    {
      icon: Settings,
      title: "Custom Packages",
      description: "Tailored solutions for your unique event needs",
      color: "from-gray-500 to-gray-700",
      features: ["Consultation", "Custom setups", "Flexible pricing"]
    }
  ];

  const handleCall = () => {
    window.location.href = "tel:+256751936627";
  };

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Powering Uganda's Celebrations & Campaigns
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            From intimate weddings to massive political rallies, we've got the expertise and equipment to make your event unforgettable
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {eventTypes.map((event, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg overflow-hidden">
              <CardContent className="p-6">
                <div className={`bg-gradient-to-br ${event.color} w-16 h-16 rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <event.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{event.title}</h3>
                <p className="text-gray-600 mb-4">{event.description}</p>
                <ul className="space-y-2 mb-6">
                  {event.features.map((feature, idx) => (
                    <li key={idx} className="text-sm text-gray-500 flex items-center">
                      <span className="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  onClick={handleCall}
                  className="w-full bg-gradient-to-r from-orange-500 to-blue-600 hover:from-orange-600 hover:to-blue-700 text-white font-semibold py-2 rounded-lg transition-all duration-300"
                >
                  Get Quote
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-orange-500 to-blue-600 rounded-2xl p-8 text-white">
          <h3 className="text-2xl md:text-3xl font-bold mb-4">
            Ready to Amplify Your Event?
          </h3>
          <p className="text-lg mb-6 opacity-90">
            Contact us for a custom quote tailored to your specific needs and budget
          </p>
          <Button 
            onClick={handleCall}
            size="lg"
            className="bg-white text-orange-600 hover:bg-orange-50 px-8 py-4 text-lg font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
          >
            Call 0751 936 627 Now
          </Button>
        </div>
      </div>
    </section>
  );
};
