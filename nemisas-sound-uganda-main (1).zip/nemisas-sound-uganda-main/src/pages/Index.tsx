
import { Hero } from "@/components/Hero";
import { Services } from "@/components/Services";
import { EventsServices } from "@/components/EventsServices";
import { Rentals } from "@/components/Rentals";
import { Gallery } from "@/components/Gallery";
import { About } from "@/components/About";
import { Testimonials } from "@/components/Testimonials";
import { Contact } from "@/components/Contact";
import { FloatingContact } from "@/components/FloatingContact";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <Services />
      <EventsServices />
      <Rentals />
      <Gallery />
      <About />
      <Testimonials />
      <Contact />
      <FloatingContact />
    </div>
  );
};

export default Index;
